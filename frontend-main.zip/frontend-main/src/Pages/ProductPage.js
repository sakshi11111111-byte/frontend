import React from "react";
import ProductDetail from "../components/ProductDetail";

function ProductPage() {
  return <ProductDetail />;
}

export default ProductPage;
